#!/bin/bash
python -m http.server 8081
